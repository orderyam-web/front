//버전 관리 x

 module.exports = {
   host:'orderyam-dbinstance.cfujwnblgk9a.ap-northeast-2.rds.amazonaws.com',
   user:'admin',
   password:'cpekclwm22',
   database:'yamyam'
 };

// DB 테스트
